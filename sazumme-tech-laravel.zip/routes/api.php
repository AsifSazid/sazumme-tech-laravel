<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\RegisteredUserController;

// Route::post('/send-otp', [RegisteredUserController::class, 'sendOtp']);
// Route::post('/verify-otp', [RegisteredUserController::class, 'verifyOtp']);
