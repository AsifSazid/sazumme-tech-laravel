
<div class="section techwix-brand-section techwix-brand-section-03">
    <div class="container">
        <!-- Brand Wrapper Start -->
        <div class="brand-wrapper text-center">

            <!-- Brand Active Start -->
            <div class="brand-active">
                <div class="swiper-container">
                    <div class="swiper-wrapper">
                        <!-- Single Brand Start -->
                        <div class="swiper-slide single-brand">
                            <img src="{{ asset('ui/frontend/assets') }}/images/brand/brand-1.png" alt="Brand">
                        </div>
                        <!-- Single Brand End -->
                        <!-- Single Brand Start -->
                        <div class="swiper-slide single-brand">
                            <img src="{{ asset('ui/frontend/assets') }}/images/brand/brand-2.png" alt="Brand">
                        </div>
                        <!-- Single Brand End -->
                        <!-- Single Brand Start -->
                        <div class="swiper-slide single-brand">
                            <img src="{{ asset('ui/frontend/assets') }}/images/brand/brand-3.png" alt="Brand">
                        </div>
                        <!-- Single Brand End -->
                        <!-- Single Brand Start -->
                        <div class="swiper-slide single-brand">
                            <img src="{{ asset('ui/frontend/assets') }}/images/brand/brand-4.png" alt="Brand">
                        </div>
                        <!-- Single Brand End -->
                        <!-- Single Brand Start -->
                        <div class="swiper-slide single-brand">
                            <img src="{{ asset('ui/frontend/assets') }}/images/brand/brand-5.png" alt="Brand">
                        </div>
                        <!-- Single Brand End -->
                        <!-- Single Brand Start -->
                        <div class="swiper-slide single-brand">
                            <img src="{{ asset('ui/frontend/assets') }}/images/brand/brand-2.png" alt="Brand">
                        </div>
                        <!-- Single Brand End -->
                    </div>
                </div>
            </div>
            <!-- Brand Active End -->
        </div>
        <!-- Brand Wrapper End -->
    </div>
</div>