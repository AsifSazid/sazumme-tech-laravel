<div id="header" class="section header-section">

    <div class="container">

        <!-- Header Wrap Start  -->
        <div class="header-wrap">

            <div class="header-logo">
                <a href="<?php echo e(route('welcome')); ?>">
                    <img src="<?php echo e(asset('ui/frontend/assets')); ?>/images/logos/full-logo.png" alt="">
                </a>
            </div>

            <div class="header-menu d-none d-lg-block">
                <ul class="main-menu">
                    <li class="active-menu">
                        <a href="<?php echo e(route('welcome')); ?>">Home</a>
                    </li>
                    <li><a href="#">About</a>
                        <ul class="sub-menu">
                            <li><a href="<?php echo e(route('about-us')); ?>">Aboute Us</a></li>
                            <li><a href="<?php echo e(route('our-team')); ?>">Our Team</a></li>
                            <li><a href="<?php echo e(route('choose-us')); ?>">Why Choose Us</a></li>
                            <li><a href="<?php echo e(route('clients-testimonial')); ?>">Testimonial</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="<?php echo e(route('our-services')); ?>">Our Service</a>
                    </li>
                    <li><a href="<?php echo e(route('pricing')); ?>">Pricing</a></li>
                    
                    <li><a href="<?php echo e(route('contact-us')); ?>">Contact</a></li>
                </ul>
            </div>

            <!-- Header Meta Start -->
            <div class="header-meta">
                <!-- Header Cart Start -->
                
                <!-- Header Cart End -->
                <!-- Header Search Start -->
                <div class="header-search">
                    <a class="search-btn" href="#"><i class="flaticon-loupe"></i></a>
                    <div class="search-wrap">
                        <div class="search-inner">
                            <i id="search-close" class="flaticon-close search-close"></i>
                            <div class="search-cell">
                                <form action="#">
                                    <div class="search-field-holder">
                                        <input class="main-search-input" type="search"
                                            placeholder="Search Your Keyword...">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Header Search End -->

                <div class="header-btn d-none d-xl-block">
                    <a class="btn" href="<?php echo e(route('login')); ?>">Get Started</a>
                </div>
                <!-- Header Toggle Start -->
                <div class="header-toggle d-lg-none">
                    <button data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample">
                        <span></span>
                        <span></span>
                        <span></span>
                    </button>
                </div>
                <!-- Header Toggle End -->
            </div>
            <!-- Header Meta End  -->

        </div>
        <!-- Header Wrap End  -->

    </div>
</div>

<div class="offcanvas offcanvas-start" id="offcanvasExample">
    <div class="offcanvas-header">
        <!-- Offcanvas Logo Start -->
        <div class="offcanvas-logo">
            <a href="index.html"><img src="<?php echo e(asset('ui/frontend/assets')); ?>/images/logos/full-logo.png"
                    alt=""></a>
        </div>
        <!-- Offcanvas Logo End -->
        <button type="button" class="close-btn" data-bs-dismiss="offcanvas"><i class="flaticon-close"></i></button>
    </div>

    <!-- Offcanvas Body Start -->
    <div class="offcanvas-body">
        <div class="offcanvas-menu">
            <ul class="main-menu">
                <li class="active-menu">
                    <a href="index.html">Home</a>
                </li>
                <li>
                    <a href="about.html">Aboute Us</a>
                </li>
                <li><a href="#">Pages</a>
                    <ul class="sub-menu">
                        <li><a href="team.html">Our Team</a></li>
                        <li><a href="service.html">Service</a></li>
                        <li><a href="choose-us.html">Why Choose Us</a></li>
                        <li><a href="testimonial.html">Testimonial</a></li>
                        <li><a href="pricing.html">Pricing</a></li>
                        <li><a href="login-register.html">Login & Register</a></li>
                    </ul>
                </li>
                <li><a href="#">Blog</a>
                    <ul class="sub-menu">
                        <li><a href="blog.html">Blog Grid</a></li>
                        <li><a href="blog-standard.html">Blog List</a></li>
                        <li><a href="blog-details.html">Blog Single</a></li>
                    </ul>
                </li>
                <li><a href="contact.html">Contact</a></li>
            </ul>
        </div>
    </div>
    <!-- Offcanvas Body End -->
</div>
<?php /**PATH C:\laragon\www\sazumme-tech-laravel\resources\views/components/frontend/layouts/partials/header.blade.php ENDPATH**/ ?>