<?php if (isset($component)) { $__componentOriginal56a4d1c64bee0e6f2d21e0b46a5321ae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal56a4d1c64bee0e6f2d21e0b46a5321ae = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginalb033198df3608a5f2d6d79495dd14d32 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb033198df3608a5f2d6d79495dd14d32 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.layouts.partials.page-banner','data' => ['pageTitle' => 'Our Wings']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.layouts.partials.page-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageTitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Our Wings')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb033198df3608a5f2d6d79495dd14d32)): ?>
<?php $attributes = $__attributesOriginalb033198df3608a5f2d6d79495dd14d32; ?>
<?php unset($__attributesOriginalb033198df3608a5f2d6d79495dd14d32); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb033198df3608a5f2d6d79495dd14d32)): ?>
<?php $component = $__componentOriginalb033198df3608a5f2d6d79495dd14d32; ?>
<?php unset($__componentOriginalb033198df3608a5f2d6d79495dd14d32); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginala2b99ef7e4490299dda8af20dbf98b7f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala2b99ef7e4490299dda8af20dbf98b7f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.sections.wings','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.sections.wings'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala2b99ef7e4490299dda8af20dbf98b7f)): ?>
<?php $attributes = $__attributesOriginala2b99ef7e4490299dda8af20dbf98b7f; ?>
<?php unset($__attributesOriginala2b99ef7e4490299dda8af20dbf98b7f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala2b99ef7e4490299dda8af20dbf98b7f)): ?>
<?php $component = $__componentOriginala2b99ef7e4490299dda8af20dbf98b7f; ?>
<?php unset($__componentOriginala2b99ef7e4490299dda8af20dbf98b7f); ?>
<?php endif; ?>

    <?php $__env->startPush('css'); ?>
        <style>
            .choose-us-img .icon {
                color: #89c4e6;
                /* soft blue */
                font-size: 40px;
                flex-shrink: 0;
                margin-top: 4px;
            }

            .choose-us-link {
                text-decoration: none;
                color: inherit;
                display: block;
                transition: transform 0.3s ease, box-shadow 0.3s ease;
            }

            .choose-us-link:hover .choose-us-item-02 {
                transform: translateY(-6px);
                box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
                border-radius: 12px;
                background-color: #fdfdfd;
            }
        </style>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal56a4d1c64bee0e6f2d21e0b46a5321ae)): ?>
<?php $attributes = $__attributesOriginal56a4d1c64bee0e6f2d21e0b46a5321ae; ?>
<?php unset($__attributesOriginal56a4d1c64bee0e6f2d21e0b46a5321ae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal56a4d1c64bee0e6f2d21e0b46a5321ae)): ?>
<?php $component = $__componentOriginal56a4d1c64bee0e6f2d21e0b46a5321ae; ?>
<?php unset($__componentOriginal56a4d1c64bee0e6f2d21e0b46a5321ae); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sazumme-tech-laravel\resources\views/frontend/our-wings.blade.php ENDPATH**/ ?>