<?php if (isset($component)) { $__componentOriginal56a4d1c64bee0e6f2d21e0b46a5321ae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal56a4d1c64bee0e6f2d21e0b46a5321ae = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Page Banner Start -->
    <?php if (isset($component)) { $__componentOriginalb033198df3608a5f2d6d79495dd14d32 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb033198df3608a5f2d6d79495dd14d32 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.layouts.partials.page-banner','data' => ['pageTitle' => 'About Us']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.layouts.partials.page-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageTitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('About Us')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb033198df3608a5f2d6d79495dd14d32)): ?>
<?php $attributes = $__attributesOriginalb033198df3608a5f2d6d79495dd14d32; ?>
<?php unset($__attributesOriginalb033198df3608a5f2d6d79495dd14d32); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb033198df3608a5f2d6d79495dd14d32)): ?>
<?php $component = $__componentOriginalb033198df3608a5f2d6d79495dd14d32; ?>
<?php unset($__componentOriginalb033198df3608a5f2d6d79495dd14d32); ?>
<?php endif; ?>
    <!-- Page Banner End -->

    <!-- About Start -->
    <div class="section techwix-about-section-07 section-padding">
        <div class="shape-1"></div>
        <div class="container">
            <!-- About Wrapper Start -->
            <div class="about-wrap">
                <div class="row">
                    <div class="col-lg-6">
                        <!-- About Image Wrap Start -->
                        <div class="about-img-wrap">
                            <img class="shape-1" src="<?php echo e(asset('ui/frontend/assets')); ?>/images/shape/about-shape2.png"
                                alt="">
                            <div class="about-img">
                                <img src="<?php echo e(asset('ui/frontend/assets')); ?>/images/about-big2-ai-300x453.png"
                                    alt="">
                            </div>
                            <div class="about-img about-img-2">
                                <img src="<?php echo e(asset('ui/frontend/assets')); ?>/images/about-4-ai-300x453.png"
                                    alt="">
                            </div>
                        </div>
                        <!-- About Image Wrap End -->
                    </div>
                    <div class="col-lg-6">
                        <!-- About Content Wrap Start -->
                        <div class="about-content-wrap">
                            <div class="section-title">
                                <h3 class="sub-title">Who we are</h3>
                                <h2 class="title">Empowering the Future through Innovation</h2>
                            </div>
                            <p class="text">SazUmme is a visionary ecosystem with 12 dynamic wings working across
                                technology, education, AI, agritech, branding, robotics, charity and more. Our mission
                                is to create innovative, impactful, and sustainable solutions that address real-world
                                challenges and empower communities.</p>
                            <!-- About List Start -->
                            <div class="about-list-03">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="about-list-item-03">
                                            <h3 class="title">Our Mission</h3>
                                            <p>To build a smart, inclusive and future-ready society through innovation,
                                                education and entrepreneurship.</p>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="about-list-item-03">
                                            <h3 class="title">Custom Code</h3>
                                            <p>We combine technology, human-centered design, and social good to create
                                                long-term value across industries.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- About List End -->
                        </div>
                        <!-- About Content Wrap End -->
                    </div>
                </div>
            </div>
            <!-- About Wrapper End -->
        </div>
    </div>
    <!-- About End -->

    <!-- Counter Start -->
    
    <!-- Counter End -->

    <!-- Choose Us Start -->
    <?php if (isset($component)) { $__componentOriginal1740190c79ed2ce2f6006d991c91144e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1740190c79ed2ce2f6006d991c91144e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.sections.choose-us','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.sections.choose-us'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1740190c79ed2ce2f6006d991c91144e)): ?>
<?php $attributes = $__attributesOriginal1740190c79ed2ce2f6006d991c91144e; ?>
<?php unset($__attributesOriginal1740190c79ed2ce2f6006d991c91144e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1740190c79ed2ce2f6006d991c91144e)): ?>
<?php $component = $__componentOriginal1740190c79ed2ce2f6006d991c91144e; ?>
<?php unset($__componentOriginal1740190c79ed2ce2f6006d991c91144e); ?>
<?php endif; ?>
    <!-- Choose Us End -->

    <!-- Skill Start -->
    <div class="section techwix-skill-section-02 techwix-skill-section-03 section-padding">
        <div class="container">
            <div class="skill-wrap">
                <div class="row">
                    <div class="col-lg-6">
                        <!-- Skill Left Start -->
                        <div class="skill-left">
                            <div class="section-title">
                                <h2 class="title">Our Capabilities at a Glance
                                </h2>
                            </div>
                            <div class="about-list">
                                <ul>
                                    <li>
                                        <span class="about-icon"><i class="fas fa-check"></i></span>
                                        <span class="about-text">Commitment to technical excellence </span>
                                    </li>
                                    <li>
                                        <span class="about-icon"><i class="fas fa-check"></i></span>
                                        <span class="about-text">Innovation-driven mindset across all projects</span>
                                    </li>
                                    <li>
                                        <span class="about-icon"><i class="fas fa-check"></i></span>
                                        <span class="about-text">Strategic partnership for long-term growth</span>
                                    </li>
                                </ul>
                            </div>
                            <!-- About Author Info Wrap Start -->
                            <div class="about-author-info-wrap">
                                <div class="about-author">
                                    
                                    <h3 class="name">Asif M. Sazid</h3>
                                    <span class="designation">CEO, SazUmme</span>
                                </div>
                                <div class="about-info">
                                    <p>Call to ask any question </p>
                                    <h3 class="number">+880 1684 576 384</h3>
                                </div>
                            </div>
                            <!-- About Author Info Wrap End -->
                        </div>
                        <!-- Skill Left End -->
                    </div>
                    <div class="col-lg-6">
                        <!-- Skill Right Start -->
                        <div class="skill-right">
                            <p class="text">Accelerate innovation with world-class tech teams. At SazUmme, we connect you with exceptional freelance talent to meet all your software and digital infrastructure needs — from cloud, automation, and network solutions to IT strategy. We deeply understand your business goals and craft solutions that not only meet expectations but exceed them.</p>
                            <div class="counter-bar">
                                <!-- Skill Item Start -->
                                <div class="skill-item">
                                    <span class="title">IT Consultancy</span>
                                    <div class="skill-bar">
                                        <div class="bar-inner">
                                            <div class="bar progress-line color-1" data-width="80">
                                                <span class="skill-percent"><span class="counter">80</span>%</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Skill Item End -->
                                <!-- Skill Item Start -->
                                <div class="skill-item">
                                    <span class="title">Web Design and Development</span>
                                    <div class="skill-bar">
                                        <div class="bar-inner">
                                            <div class="bar progress-line color-1" data-width="95">
                                                <span class="skill-percent"><span class="counter">95</span>%</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Skill Item End -->
                                <!-- Skill Item Start -->
                                <div class="skill-item">
                                    <span class="title">AI and Automation</span>
                                    <div class="skill-bar">
                                        <div class="bar-inner">
                                            <div class="bar progress-line color-1" data-width="70">
                                                <span class="skill-percent"><span class="counter">70</span>%</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Skill Item End -->
                            </div>
                        </div>
                        <!-- Skill Right End -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Skill End -->

    <!-- Team Start -->
    
    <!-- Team End -->

    <!-- Testimonial Start  -->
    
    <!-- Testimonial End  -->

    <!-- Cta Start -->
    <?php if (isset($component)) { $__componentOriginal51e4efeddf64b6ed5983539c8989dfe7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal51e4efeddf64b6ed5983539c8989dfe7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.layouts.partials.cta','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.layouts.partials.cta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal51e4efeddf64b6ed5983539c8989dfe7)): ?>
<?php $attributes = $__attributesOriginal51e4efeddf64b6ed5983539c8989dfe7; ?>
<?php unset($__attributesOriginal51e4efeddf64b6ed5983539c8989dfe7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal51e4efeddf64b6ed5983539c8989dfe7)): ?>
<?php $component = $__componentOriginal51e4efeddf64b6ed5983539c8989dfe7; ?>
<?php unset($__componentOriginal51e4efeddf64b6ed5983539c8989dfe7); ?>
<?php endif; ?>
    <!-- Cta End -->

    <?php $__env->startPush('css'); ?>
        <style>
            .choose-us-img .icon {
                color: #89c4e6;
                /* soft blue */
                font-size: 40px;
                flex-shrink: 0;
                margin-top: 4px;
            }
        </style>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal56a4d1c64bee0e6f2d21e0b46a5321ae)): ?>
<?php $attributes = $__attributesOriginal56a4d1c64bee0e6f2d21e0b46a5321ae; ?>
<?php unset($__attributesOriginal56a4d1c64bee0e6f2d21e0b46a5321ae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal56a4d1c64bee0e6f2d21e0b46a5321ae)): ?>
<?php $component = $__componentOriginal56a4d1c64bee0e6f2d21e0b46a5321ae; ?>
<?php unset($__componentOriginal56a4d1c64bee0e6f2d21e0b46a5321ae); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sazumme-tech-laravel\resources\views/frontend/about-us.blade.php ENDPATH**/ ?>