

<img <?php echo e($attributes); ?> width="150" height="150" src="<?php echo e(asset('ui/frontend/assets/images/logos/favicon.png')); ?>"  transform="matrix(0.5333 0 0 0.5333 752 332)" />

<?php /**PATH C:\laragon\www\sazumme-tech-laravel\resources\views/components/application-logo.blade.php ENDPATH**/ ?>