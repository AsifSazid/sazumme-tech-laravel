<div id="preloader">
    <div class="preloader">
        <span></span>
        <span></span>
    </div>
</div><?php /**PATH C:\laragon\www\sazumme-tech-laravel\resources\views/components/frontend/layouts/partials/preloader.blade.php ENDPATH**/ ?>