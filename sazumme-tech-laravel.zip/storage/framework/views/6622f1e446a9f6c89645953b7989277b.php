<?php if (isset($component)) { $__componentOriginal56a4d1c64bee0e6f2d21e0b46a5321ae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal56a4d1c64bee0e6f2d21e0b46a5321ae = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Hero Start -->
        <?php if (isset($component)) { $__componentOriginal2a1b0810d26fd402f774a66df69e66d9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2a1b0810d26fd402f774a66df69e66d9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.sections.welcome-section.hero-area','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.sections.welcome-section.hero-area'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2a1b0810d26fd402f774a66df69e66d9)): ?>
<?php $attributes = $__attributesOriginal2a1b0810d26fd402f774a66df69e66d9; ?>
<?php unset($__attributesOriginal2a1b0810d26fd402f774a66df69e66d9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a1b0810d26fd402f774a66df69e66d9)): ?>
<?php $component = $__componentOriginal2a1b0810d26fd402f774a66df69e66d9; ?>
<?php unset($__componentOriginal2a1b0810d26fd402f774a66df69e66d9); ?>
<?php endif; ?>
        <!-- Hero End -->
        
    <!-- Service Start -->
        <?php if (isset($component)) { $__componentOriginalbfb713cf717ca5777a2b95382685b5cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfb713cf717ca5777a2b95382685b5cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.sections.welcome-section.service','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.sections.welcome-section.service'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfb713cf717ca5777a2b95382685b5cb)): ?>
<?php $attributes = $__attributesOriginalbfb713cf717ca5777a2b95382685b5cb; ?>
<?php unset($__attributesOriginalbfb713cf717ca5777a2b95382685b5cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfb713cf717ca5777a2b95382685b5cb)): ?>
<?php $component = $__componentOriginalbfb713cf717ca5777a2b95382685b5cb; ?>
<?php unset($__componentOriginalbfb713cf717ca5777a2b95382685b5cb); ?>
<?php endif; ?>
    <!-- Service End -->

    <!-- About Start -->
        <?php if (isset($component)) { $__componentOriginal149f1f55f5e0c5037af8f70bc41b5e5e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal149f1f55f5e0c5037af8f70bc41b5e5e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.sections.welcome-section.about','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.sections.welcome-section.about'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal149f1f55f5e0c5037af8f70bc41b5e5e)): ?>
<?php $attributes = $__attributesOriginal149f1f55f5e0c5037af8f70bc41b5e5e; ?>
<?php unset($__attributesOriginal149f1f55f5e0c5037af8f70bc41b5e5e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal149f1f55f5e0c5037af8f70bc41b5e5e)): ?>
<?php $component = $__componentOriginal149f1f55f5e0c5037af8f70bc41b5e5e; ?>
<?php unset($__componentOriginal149f1f55f5e0c5037af8f70bc41b5e5e); ?>
<?php endif; ?>
    <!-- About End -->

    <!-- Counter Start -->
        
    <!-- Counter End -->

    <!-- Choose Us Start -->
        <?php if (isset($component)) { $__componentOriginal805bdef2c9dc17b2c2c1598706736330 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal805bdef2c9dc17b2c2c1598706736330 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.sections.welcome-section.choose-us','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.sections.welcome-section.choose-us'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal805bdef2c9dc17b2c2c1598706736330)): ?>
<?php $attributes = $__attributesOriginal805bdef2c9dc17b2c2c1598706736330; ?>
<?php unset($__attributesOriginal805bdef2c9dc17b2c2c1598706736330); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal805bdef2c9dc17b2c2c1598706736330)): ?>
<?php $component = $__componentOriginal805bdef2c9dc17b2c2c1598706736330; ?>
<?php unset($__componentOriginal805bdef2c9dc17b2c2c1598706736330); ?>
<?php endif; ?>
    <!-- Choose Us End -->

    <!-- Skill Start -->
        
    <!-- Skill End -->

    <!-- Testimonial Start  -->
        
    <!-- Testimonial End  -->

    <!-- Team Start -->
        
    <!-- Team End -->

    <!-- Cta Start -->
        <?php if (isset($component)) { $__componentOriginal51e4efeddf64b6ed5983539c8989dfe7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal51e4efeddf64b6ed5983539c8989dfe7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.layouts.partials.cta','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.layouts.partials.cta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal51e4efeddf64b6ed5983539c8989dfe7)): ?>
<?php $attributes = $__attributesOriginal51e4efeddf64b6ed5983539c8989dfe7; ?>
<?php unset($__attributesOriginal51e4efeddf64b6ed5983539c8989dfe7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal51e4efeddf64b6ed5983539c8989dfe7)): ?>
<?php $component = $__componentOriginal51e4efeddf64b6ed5983539c8989dfe7; ?>
<?php unset($__componentOriginal51e4efeddf64b6ed5983539c8989dfe7); ?>
<?php endif; ?>
    <!-- Cta End -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal56a4d1c64bee0e6f2d21e0b46a5321ae)): ?>
<?php $attributes = $__attributesOriginal56a4d1c64bee0e6f2d21e0b46a5321ae; ?>
<?php unset($__attributesOriginal56a4d1c64bee0e6f2d21e0b46a5321ae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal56a4d1c64bee0e6f2d21e0b46a5321ae)): ?>
<?php $component = $__componentOriginal56a4d1c64bee0e6f2d21e0b46a5321ae; ?>
<?php unset($__componentOriginal56a4d1c64bee0e6f2d21e0b46a5321ae); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sazumme-tech-laravel\resources\views/welcome.blade.php ENDPATH**/ ?>