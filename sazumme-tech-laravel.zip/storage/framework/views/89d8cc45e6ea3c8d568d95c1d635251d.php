<!doctype html>
<html class="no-js" lang="en">


<!-- Mirrored from thepixelcurve.com/html/techwix/techwix/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 29 Jan 2025 11:16:56 GMT -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>SazUmme - IT Solutions Consultancy</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('ui/frontend/assets')); ?>/images/logos/favicon.png">

    <!-- CSS
 ============================================ -->

    <!-- Icon Font CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('ui/frontend/assets')); ?>/css/plugins/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('ui/frontend/assets')); ?>/css/plugins/flaticon.css">

    <!-- Plugins CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('ui/frontend/assets')); ?>/css/plugins/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('ui/frontend/assets')); ?>/css/plugins/swiper-bundle.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('ui/frontend/assets')); ?>/css/plugins/aos.css">
    <link rel="stylesheet" href="<?php echo e(asset('ui/frontend/assets')); ?>/css/plugins/magnific-popup.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('ui/frontend/assets')); ?>/css/style.css">

    <?php echo $__env->yieldPushContent('css'); ?>

    <!--====== Use the minified version files listed below for better performance and remove the files listed above ======-->
    <!-- <link rel="stylesheet" href="<?php echo e(asset('ui/frontend/assets')); ?>/css/vendor/plugins.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('ui/frontend/assets')); ?>/css/style.min.css"> -->

</head>

<body>


    <div class="main-wrapper">

        <!-- Preloader start -->
        <?php if (isset($component)) { $__componentOriginal80c4cfb275697cda8486f9b7c935c078 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal80c4cfb275697cda8486f9b7c935c078 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.layouts.partials.preloader','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.layouts.partials.preloader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal80c4cfb275697cda8486f9b7c935c078)): ?>
<?php $attributes = $__attributesOriginal80c4cfb275697cda8486f9b7c935c078; ?>
<?php unset($__attributesOriginal80c4cfb275697cda8486f9b7c935c078); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal80c4cfb275697cda8486f9b7c935c078)): ?>
<?php $component = $__componentOriginal80c4cfb275697cda8486f9b7c935c078; ?>
<?php unset($__componentOriginal80c4cfb275697cda8486f9b7c935c078); ?>
<?php endif; ?>
        <!-- Preloader End -->

        <!-- Header Start  -->
        <?php if (isset($component)) { $__componentOriginal07c274c48482053fdb371dd141a61e59 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal07c274c48482053fdb371dd141a61e59 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.layouts.partials.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.layouts.partials.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal07c274c48482053fdb371dd141a61e59)): ?>
<?php $attributes = $__attributesOriginal07c274c48482053fdb371dd141a61e59; ?>
<?php unset($__attributesOriginal07c274c48482053fdb371dd141a61e59); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal07c274c48482053fdb371dd141a61e59)): ?>
<?php $component = $__componentOriginal07c274c48482053fdb371dd141a61e59; ?>
<?php unset($__componentOriginal07c274c48482053fdb371dd141a61e59); ?>
<?php endif; ?>
        <!-- Header End -->

        
        <?php echo e($slot); ?>



        <!-- Footer Section Start -->
        <?php if (isset($component)) { $__componentOriginal8bea8c403b86d9263d8873ab04a84f0f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8bea8c403b86d9263d8873ab04a84f0f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.layouts.partials.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.layouts.partials.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8bea8c403b86d9263d8873ab04a84f0f)): ?>
<?php $attributes = $__attributesOriginal8bea8c403b86d9263d8873ab04a84f0f; ?>
<?php unset($__attributesOriginal8bea8c403b86d9263d8873ab04a84f0f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bea8c403b86d9263d8873ab04a84f0f)): ?>
<?php $component = $__componentOriginal8bea8c403b86d9263d8873ab04a84f0f; ?>
<?php unset($__componentOriginal8bea8c403b86d9263d8873ab04a84f0f); ?>
<?php endif; ?>
        <!-- Footer Section End -->

        <!-- back to top start -->
        <div class="progress-wrap">
            <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
                <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
            </svg>
        </div>
        <!-- back to top end -->

    </div>

    <!-- JS
    ============================================ -->
    <script src="<?php echo e(asset('ui/frontend/assets')); ?>/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="<?php echo e(asset('ui/frontend/assets')); ?>/js/vendor/modernizr-3.11.2.min.js"></script>

    <!-- Bootstrap JS -->
    <script src="<?php echo e(asset('ui/frontend/assets')); ?>/js/plugins/popper.min.js"></script>
    <script src="<?php echo e(asset('ui/frontend/assets')); ?>/js/plugins/bootstrap.min.js"></script>

    <!-- Plugins JS -->
    <script src="<?php echo e(asset('ui/frontend/assets')); ?>/js/plugins/swiper-bundle.min.js"></script>
    <script src="<?php echo e(asset('ui/frontend/assets')); ?>/js/plugins/aos.js"></script>
    <script src="<?php echo e(asset('ui/frontend/assets')); ?>/js/plugins/waypoints.min.js"></script>
    <script src="<?php echo e(asset('ui/frontend/assets')); ?>/js/plugins/back-to-top.js"></script>
    <script src="<?php echo e(asset('ui/frontend/assets')); ?>/js/plugins/jquery.counterup.min.js"></script>
    <script src="<?php echo e(asset('ui/frontend/assets')); ?>/js/plugins/appear.min.js"></script>
    <script src="<?php echo e(asset('ui/frontend/assets')); ?>/js/plugins/jquery.magnific-popup.min.js"></script>


    <!--====== Use the minified version files listed below for better performance and remove the files listed above ======-->


    <!-- Main JS -->
    <script src="<?php echo e(asset('ui/frontend/assets')); ?>/js/main.js"></script>

</body>


<!-- Mirrored from thepixelcurve.com/html/techwix/techwix/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 29 Jan 2025 11:17:34 GMT -->

</html>
<?php /**PATH C:\laragon\www\sazumme-tech-laravel\resources\views/components/frontend/layouts/master.blade.php ENDPATH**/ ?>