<?php if (isset($component)) { $__componentOriginal56a4d1c64bee0e6f2d21e0b46a5321ae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal56a4d1c64bee0e6f2d21e0b46a5321ae = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.layouts.master','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.layouts.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Page Banner Start -->
    <?php if (isset($component)) { $__componentOriginalb033198df3608a5f2d6d79495dd14d32 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb033198df3608a5f2d6d79495dd14d32 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.layouts.partials.page-banner','data' => ['pageTitle' => 'Our Team']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.layouts.partials.page-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageTitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Our Team')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb033198df3608a5f2d6d79495dd14d32)): ?>
<?php $attributes = $__attributesOriginalb033198df3608a5f2d6d79495dd14d32; ?>
<?php unset($__attributesOriginalb033198df3608a5f2d6d79495dd14d32); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb033198df3608a5f2d6d79495dd14d32)): ?>
<?php $component = $__componentOriginalb033198df3608a5f2d6d79495dd14d32; ?>
<?php unset($__componentOriginalb033198df3608a5f2d6d79495dd14d32); ?>
<?php endif; ?>
    <!-- Page Banner End -->

    <?php if (isset($component)) { $__componentOriginal577838afbe4b3bf4558aed9171088540 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal577838afbe4b3bf4558aed9171088540 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frontend.sections.undermaintainace','data' => ['pageTitle' => 'Our Team']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.sections.undermaintainace'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageTitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Our Team')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal577838afbe4b3bf4558aed9171088540)): ?>
<?php $attributes = $__attributesOriginal577838afbe4b3bf4558aed9171088540; ?>
<?php unset($__attributesOriginal577838afbe4b3bf4558aed9171088540); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal577838afbe4b3bf4558aed9171088540)): ?>
<?php $component = $__componentOriginal577838afbe4b3bf4558aed9171088540; ?>
<?php unset($__componentOriginal577838afbe4b3bf4558aed9171088540); ?>
<?php endif; ?>
    <!-- Team Start -->
    
    <!-- Team End -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal56a4d1c64bee0e6f2d21e0b46a5321ae)): ?>
<?php $attributes = $__attributesOriginal56a4d1c64bee0e6f2d21e0b46a5321ae; ?>
<?php unset($__attributesOriginal56a4d1c64bee0e6f2d21e0b46a5321ae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal56a4d1c64bee0e6f2d21e0b46a5321ae)): ?>
<?php $component = $__componentOriginal56a4d1c64bee0e6f2d21e0b46a5321ae; ?>
<?php unset($__componentOriginal56a4d1c64bee0e6f2d21e0b46a5321ae); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sazumme-tech-laravel\resources\views/frontend/our-team.blade.php ENDPATH**/ ?>